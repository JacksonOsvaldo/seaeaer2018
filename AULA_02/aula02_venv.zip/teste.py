try:
    import pandas as pd
    print('Importação Concluída!')
except ImportError:
    print('Importação deu bug, mano(a). Revisa essa parada aí. :)')

